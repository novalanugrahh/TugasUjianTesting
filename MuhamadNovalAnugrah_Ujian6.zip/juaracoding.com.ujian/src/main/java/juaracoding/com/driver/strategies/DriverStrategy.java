package juaracoding.com.driver.strategies;

import org.openqa.selenium.WebDriver;

public interface DriverStrategy {

	WebDriver setStrategy();
}
