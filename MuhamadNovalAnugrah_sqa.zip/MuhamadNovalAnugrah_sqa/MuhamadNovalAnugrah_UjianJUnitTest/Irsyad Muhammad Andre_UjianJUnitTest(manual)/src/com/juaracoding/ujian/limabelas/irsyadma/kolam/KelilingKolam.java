package com.juaracoding.ujian.limabelas.irsyadma.kolam;

public class KelilingKolam {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public static double HitungKelilingKolam(double panjang,double lebar,double tinggi) {
		double hasil = (panjang+lebar+tinggi)*4;
		return hasil;
	}

}
