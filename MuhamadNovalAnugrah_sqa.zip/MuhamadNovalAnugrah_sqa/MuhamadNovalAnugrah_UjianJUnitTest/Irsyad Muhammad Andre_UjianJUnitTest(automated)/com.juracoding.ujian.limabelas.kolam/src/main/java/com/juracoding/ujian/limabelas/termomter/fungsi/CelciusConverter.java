package com.juracoding.ujian.limabelas.termomter.fungsi;

public class CelciusConverter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public static double FahreinheitConvCelcius(double fah) {
		double celcius = ((fah-32)*5)/9;
		return celcius;
		
	}
	

}
