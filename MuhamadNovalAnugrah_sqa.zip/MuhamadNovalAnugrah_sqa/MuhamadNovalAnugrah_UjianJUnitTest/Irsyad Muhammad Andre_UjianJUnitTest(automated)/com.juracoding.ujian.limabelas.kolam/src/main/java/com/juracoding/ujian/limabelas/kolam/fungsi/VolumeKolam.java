package com.juracoding.ujian.limabelas.kolam.fungsi;

public class VolumeKolam {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public static double HitungVolumegKolam(double panjang,double lebar,double tinggi) {
		double hasil = panjang*lebar*tinggi;
		return hasil;
	}

}
