package com.juaracoding.tigabelas.tugaspostest.kecepatanrata;

public class KecepatanRata {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	public static double kecRata(double jarak,double waktu) {
		double hasil = jarak/waktu;
		return hasil;
	}

}
